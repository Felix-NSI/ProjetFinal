from tkinter import *
from random import *
window = Tk()
window.title('D3CR1PT0')
window.geometry('1080x720')
window.minsize(1000,500)
window.iconbitmap("icon.ico")
window['bg'] = 'black'

#Functions

def cryptageLettre(lettre, alphabet, cle):
    for i in range(len(alphabet)):
        if lettre == ' ':
            return ' '
        elif alphabet[i] == lettre:
            return alphabet[i + cle]
    return lettre


def crypt1(texte, cle):
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
                'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    texteCrypte = str()
    for lettre in texte:
        lettre = lettre.upper()
        texteCrypte += cryptageLettre(lettre, alphabet, cle)

    return texteCrypte


def debut2(texte,cle):
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
                'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

    texteDecrypte = str()
    for lettre in texte:
        lettre = lettre.upper()
        texteDecrypte += decryptageLettre(lettre, alphabet, cle)
    return texteDecrypte


def decryptageLettre(lettre, alphabet, cle):
    for i in range(len(alphabet)):
        if lettre == ' ':
            return ' '
        elif alphabet[i] == lettre:
            return str(alphabet[i - cle])
    return lettre


# debut2()

def decryptageLettre(lettre, alphabet, cleA):
    for i in range(len(alphabet)):
        if lettre == ' ':
            return ' '
        if alphabet[i] == lettre:
            return str(alphabet[i - cleA])
    return lettre


def debut3():
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
                'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    cleA = 1
    texte = str(input('Quel est le texte a décrypter ?'))
    for i in range(25):
        texteDecrypte = str()
        for lettre in texte:
            lettre = lettre.upper()
            texteDecrypte += decryptageLettre(lettre, alphabet, cleA)
        print("Tentative de décryptage avec une clé de", cleA, ":", texteDecrypte)

        ressemblance = input("Si vous visualisez le texte en clair rentrer un caractère sinon entrée.")

        if ressemblance.isalpha():
            print("Le texte décrypté :", texteDecrypte, "à été décrypté avec la clé de", cleA)
            break
        elif cleA == 25:
            print(
                "Désolé, vous avez essayé toutes les valeurs de clé, le texte  a été  crypté selon une méthode différente au code de César.")
            break
        elif ressemblance == ' ' or ressemblance == '':
            cleA += 1
        # debut3()


def debut4(texte):
    alphabetMorse = {"A": ' .-', "B": ' -...', "C": ' -.-.', "D": ' -..', "E": ' .', "F": ' ..-.', "G": ' --.',
                     "H": ' ....', "I": ' ..', "J": ' .---', "K": ' -.-', "L": ' .-..', "M": ' --', "N": ' -.',
                     "O": ' ---', "P": ' .--.', "Q": ' --.-', "R": ' .-.', "S": ' ...', "T": ' -', "U": ' ..-',
                     "V": ' ...-', "W": ' .--', "X": ' -..-', "Y": ' -.--', "Z": ' --..', " ": "~"}

    texteCryptéM = str()
    for lettre in texte:
        texteCryptéM += cryptageLettreM(lettre, alphabetMorse)
    return texteCryptéM


def cryptageLettreM(lettre, alphabetMorse):
    if lettre.isalpha():
        lettre = lettre.upper()
        lettre = alphabetMorse[lettre]
        return lettre

    elif lettre == ' ':
        return ' ~ '


# debut4()


def debut5(texte):
    alphabetinvers = {'.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E', '..-.': 'F', '--.': 'G', '....': 'H',
                      '..': 'I', '.---': 'J', '-.-': 'K', '.-..': 'L', '--': 'M', '-.': 'N', '---': 'O', '.--.': 'P',
                      '--.-': 'Q', '.-.': 'R', '...': 'S', '-': 'T', '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X',
                      '-.--': 'Y', '--..': 'Z', '~': ' '}
    texteDecrypteM = str()
    texte = texte.split(' ')
    for symb in texte:
        if symb != '':
            texteDecrypteM += decryptMorse(symb, alphabetinvers)
        else:
            continue

    return(texteDecrypteM)


def decryptMorse(symb, alphabetinvers):
    retour = alphabetinvers[symb]
    return retour


# debut5()


def decryptageR(texte, cleR):
    out = ''
    justeavant = []
    taille = len(cleR)
    for lettre in texte:

        if taille < len(justeavant):
            justeavant.pop(0)

        if lettre.isupper():
            justeavantStr = ''
            for c in range(taille):
                justeavantStr += str(justeavant[c])

            if justeavantStr != cleR:
                out += lettre
        elif lettre.isspace():
            out += lettre
        else:
            out = out
        justeavant.append(lettre)
    return out


def debut7():
    texte = str(input('Quel est le texte a décrypter ?'))
    cleR = str(input("Quelle est la clé ?"))
    texteDecrypteR = decryptageR(texte, cleR)

    print(texteDecrypteR)

def openMenu():
    window.destroy()
    menu= Tk()
    menu.title('D3CR1PT0 [Menu]')
    menu.geometry('1080x720')
    menu.iconbitmap("icon.ico")
    menu['bg'] = 'black'

    label_menu = Label(menu,text="Sélectionnez le code que vous souhaitez traiter", font=('',35), bg='black', fg='green')
    cesar = Button(menu,text='  César  ', font=('',60), bg='black', fg='green',command=menuCesar)
    morse = Button(menu,text=' Morse ', font=('', 60), bg='black', fg='green',command=menuMorse)
    projetR = Button(menu,text='Projet R', font=('', 60), bg='black', fg='green',command=menuProjetR)
    label_menu.pack(side=TOP)
    cesar.pack(side=TOP,fill=X,expand=True)
    morse.pack(side=TOP,fill=X,expand=True)
    projetR.pack(side=TOP,fill=X,expand=True)


def menuCesar():
    menuCesar = Tk()
    menuCesar.title('D3CR1PT0 [Menu César]')
    menuCesar.geometry('1080x720')
    menuCesar.iconbitmap("icon.ico")
    menuCesar['bg'] = 'black'


    label_menuCesar = Label(menuCesar,text="Sélectionnez l'action que vous voulez effectuer", font=('',35), bg='black', fg='green')
    button_cryptageCesar = Button(menuCesar,text='Cryptage', font=('',60), bg='black', fg='green',command=cryptageCesar)
    button_decryptageCesar = Button(menuCesar,text='Décryptage', font=('', 60), bg='black', fg='green',command=decryptageCesar)
    button_decryptageSansCleCesar = Button(menuCesar,text='Décryptage sans clé', font=('', 60), bg='black', fg='green')
    label_menuCesar.pack(side=TOP)
    button_cryptageCesar.pack(side=TOP,fill=X,expand=True)
    button_decryptageCesar.pack(side=TOP,fill=X,expand=True)



def cryptageCesar():
    cryptageCesar = Tk()
    cryptageCesar.title('D3CR1PT0 [Cryptage César]')
    cryptageCesar.geometry('640x250')
    cryptageCesar.iconbitmap("icon.ico")
    cryptageCesar['bg'] = 'black'

    def cryptageCesarButton():
        label_texteCrypteCesar['text'] = crypt1(str(entryCryptage.get()),int(entryCleCesarCryptage.get()))
        return None

    cesarCrypte = StringVar()
    cleCryptage = IntVar()
    label_cryptageCesar = Label(cryptageCesar, text="Inserez le texte à crypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryCryptage = Entry(cryptageCesar,width = 50, textvariable=cesarCrypte)
    label_cleCesarCryptage = Label(cryptageCesar, text="Inserez la clé de cryptage ci dessous :", font=('', 20),bg='black', fg='green')
    entryCleCesarCryptage = Entry(cryptageCesar, width=2, textvariable=cleCryptage)
    label_texteCrypteCesar = Label(cryptageCesar, text="Texte Crypté", font=('', 20),bg='black', fg='green')
    button_cryptageCesar = Button(cryptageCesar,text='Crypter !', font=('', 20), bg='black', fg='green',command=cryptageCesarButton)
    label_cryptageCesar.pack(side=TOP)
    entryCryptage.pack(side=TOP)
    label_cleCesarCryptage.pack(side=TOP)
    entryCleCesarCryptage.pack(side=TOP)
    button_cryptageCesar.pack(side=TOP,pady=20)
    label_texteCrypteCesar.pack(side=TOP)

def decryptageCesar():
    decryptageCesar = Tk()
    decryptageCesar.title('D3CR1PT0 [Déryptage César]')
    decryptageCesar.geometry('640x250')
    decryptageCesar.iconbitmap("icon.ico")
    decryptageCesar['bg'] = 'black'

    def decryptageCesarButton():
        label_texteDecrypteCesar['text'] = debut2(str(entryDecryptage.get()),int(entryCleCesar.get()))
        return None

    cesarDecrypte = StringVar()
    cleDecryptage = StringVar()
    label_decryptageCesar = Label(decryptageCesar, text="Inserez le texte à décrypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryDecryptage = Entry(decryptageCesar,width = 50, textvariable=cesarDecrypte)
    label_cleCesar = Label(decryptageCesar, text="Inserez la clé de décryptage ci dessous :", font=('', 20),bg='black', fg='green')
    entryCleCesar = Entry(decryptageCesar, width=2, textvariable=cleDecryptage)
    label_texteDecrypteCesar = Label(decryptageCesar, text="Texte Décrypté", font=('', 20),bg='black', fg='green')
    button_decryptageCesar = Button(decryptageCesar, text='Décrypter !', font=('', 20), bg='black', fg='green',command=decryptageCesarButton)
    label_decryptageCesar.pack(side=TOP)
    entryDecryptage.pack(side=TOP)
    label_cleCesar.pack(side=TOP)
    entryCleCesar.pack(side=TOP)
    button_decryptageCesar.pack(side=TOP,pady=20)
    label_texteDecrypteCesar.pack(side=TOP)



def menuMorse():
    menuMorse = Tk()
    menuMorse.title('D3CR1PT0 [Menu Morse]')
    menuMorse.geometry('1080x720')
    menuMorse.iconbitmap("icon.ico")
    menuMorse['bg'] = 'black'

    label_menuMorse = Label(menuMorse,text="Sélectionnez l'action que vous voulez effectuer", font=('',35), bg='black', fg='green')
    button_cryptageMorse = Button(menuMorse,text=' Cryptage ', font=('',60), bg='black', fg='green',command=cryptageMorse)
    button_decryptageMorse = Button(menuMorse,text='Décryptage', font=('', 60), bg='black', fg='green',command=decryptageMorse)
    label_menuMorse.pack(side=TOP)
    button_cryptageMorse.pack(side=TOP,fill=X,expand=True)
    button_decryptageMorse.pack(side=TOP,fill=X,expand=True)

def cryptageMorse():
    cryptageMorse = Tk()
    cryptageMorse.title('D3CR1PT0 [Cryptage Morse]')
    cryptageMorse.geometry('640x250')
    cryptageMorse.iconbitmap("icon.ico")
    cryptageMorse['bg'] = 'black'

    def cryptageMorseButton():
        label_texteCrypteMorse['text'] = debut4(str(entryCryptageMorse.get()))
        return None

    morseCrypte = StringVar()
    label_cryptageMorse = Label(cryptageMorse, text="Inserez le texte à crypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryCryptageMorse = Entry(cryptageMorse,width = 50, textvariable=morseCrypte)
    label_texteCrypteMorse = Label(cryptageMorse, text="Texte Crypté", font=('', 20),bg='black', fg='green')
    button_cryptageMorse = Button(cryptageMorse,text='Crypter !', font=('', 20), bg='black', fg='green',command=cryptageMorseButton)
    label_cryptageMorse.pack(side=TOP)
    entryCryptageMorse.pack(side=TOP)
    button_cryptageMorse.pack(side=TOP,pady=20)
    label_texteCrypteMorse.pack(side=TOP)


def decryptageMorse():
    decryptageMorse = Tk()
    decryptageMorse.title('D3CR1PT0 [Décryptage Morse]')
    decryptageMorse.geometry('640x250')
    decryptageMorse.iconbitmap("icon.ico")
    decryptageMorse['bg'] = 'black'

    def decryptageMorseButton():
        label_texteDecrypteMorse['text'] = debut5(str(entryDecryptageMorse.get()))
        return None

    morseDecrypte = StringVar()
    label_decryptageMorse = Label(decryptageMorse, text="Inserez le texte à crypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryDecryptageMorse = Entry(decryptageMorse,width = 50, textvariable=morseDecrypte)
    label_texteDecrypteMorse = Label(decryptageMorse, text="Texte Décrypté", font=('', 20),bg='black', fg='green')
    button_decryptageMorse = Button(decryptageMorse,text='Décrypter !', font=('', 20), bg='black', fg='green',command=decryptageMorseButton)
    label_decryptageMorse.pack(side=TOP)
    entryDecryptageMorse.pack(side=TOP)
    button_decryptageMorse.pack(side=TOP,pady=20)
    label_texteDecrypteMorse.pack(side=TOP)


def menuProjetR():
    menuProjetR = Tk()
    menuProjetR.title('D3CR1PT0 [Menu ProjetR]')
    menuProjetR.geometry('1080x720')
    menuProjetR.iconbitmap("icon.ico")
    menuProjetR['bg'] = 'black'

    label_menuProjetR = Label(menuProjetR,text="Sélectionnez l'action que vous voulez effectuer", font=('',35), bg='black', fg='green')
    button_cryptageProjetR = Button(menuProjetR,text=' Cryptage ', font=('',60), bg='black', fg='green',command=cryptageProjetR)
    button_decryptageProjetR = Button(menuProjetR,text='Décryptage', font=('', 60), bg='black', fg='green',command=decryptageProjetR)
    label_menuProjetR.pack(side=TOP)
    button_cryptageProjetR.pack(side=TOP,fill=X,expand=True)
    button_decryptageProjetR.pack(side=TOP,fill=X,expand=True)

def cryptageProjetR():
    cryptageProjetR = Tk()
    cryptageProjetR.title('D3CR1PT0 [Cryptage ProjetR]')
    cryptageProjetR.geometry('640x250')
    cryptageProjetR.iconbitmap("icon.ico")
    cryptageProjetR['bg'] = 'black'

    def cryptageProjetRButton():
        def debut6(texte):
            alphabetmin = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                           's', 't',
                           'u', 'v', 'w', 'x', 'y', 'z', ]
            alphabetmaj = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                           'S', 'T',
                           'U', 'V', 'W', 'X', 'Y', 'Z']
            return cryptageR(texte, alphabetmin, alphabetmaj)

        def defcleR(alphabetmin):
            cleR = ''
            hasacle = randint(2, 6)
            for i in range(hasacle):
                cleR += alphabetmin[randint(0, 25)]
            label_cleR['text'] = cleR
            return cleR

        def cryptageR(texte, alphabetmin, alphabetmaj):
            nouvTexte = ''
            for a in texte:
                nouvTexte += a.upper()

                out = ''
                cleR = defcleR(alphabetmin)
                for lettre in nouvTexte:
                    bon = False
                    while bon == False:
                        hasa = randint(0, 30)
                        if hasa == 26:
                            out += lettre
                            bon = True
                        elif hasa >= 27:
                            out += cleR
                            out += alphabetmaj[randint(0, 25)]
                        else:
                            out += alphabetmin[hasa]
            print(cleR,out)
            return out
        label_texteCrypteProjetR['text'] = debut6(str(entryCryptageProjetR.get()))

        return None

    projetRCrypte = StringVar()
    label_cryptageProjetR = Label(cryptageProjetR, text="Inserez le texte à crypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryCryptageProjetR = Entry(cryptageProjetR,width = 50, textvariable=projetRCrypte)
    label_texteCrypteProjetR = Label(cryptageProjetR, text="Texte Crypté", font=('', 20),bg='black', fg='green')
    label_info = Label(cryptageProjetR, text="Si le texte n'est pas complet vous pouvez retrouver la clé ainsi que le texte dans la console", font=('', 10), bg='black', fg='green')
    button_cryptageProjetR = Button(cryptageProjetR,text='Crypter !', font=('', 20), bg='black', fg='green',command=cryptageProjetRButton)
    label_cleR = Label(cryptageProjetR, text="Clé de Décryptage", font=('', 20),bg='black', fg='green')
    label_cryptageProjetR.pack(side=TOP)
    entryCryptageProjetR.pack(side=TOP)
    button_cryptageProjetR.pack(side=TOP,pady=20)
    label_info.pack(side=TOP)
    label_texteCrypteProjetR.pack(side=TOP)
    label_cleR.pack(side=TOP)

def decryptageProjetR():
    decryptageProjetR = Tk()
    decryptageProjetR.title('D3CR1PT0 [Déryptage ProjetR]')
    decryptageProjetR.geometry('640x250')
    decryptageProjetR.iconbitmap("icon.ico")
    decryptageProjetR['bg'] = 'black'

    def decryptageProjetRButton():
        label_texteDecrypteProjetR['text'] = decryptageR(str(entryDecryptageProjetR.get()),str(entryCleProjetR.get()))
        return None

    projetRDecrypte = StringVar()
    cleDecryptageProjetR = StringVar()
    label_decryptageProjetR = Label(decryptageProjetR, text="Inserez le texte à décrypter ci dessous :", font=('', 20),bg='black', fg='green')
    entryDecryptageProjetR = Entry(decryptageProjetR,width = 50, textvariable=projetRDecrypte)
    label_cleProjetR = Label(decryptageProjetR, text="Inserez la clé de décryptage ci dessous :", font=('', 20),bg='black', fg='green')
    entryCleProjetR = Entry(decryptageProjetR, width=50, textvariable=cleDecryptageProjetR)
    label_texteDecrypteProjetR = Label(decryptageProjetR, text="Texte Décrypté", font=('', 20),bg='black', fg='green')
    button_decryptageProjetR = Button(decryptageProjetR,text='Decrypter !', font=('', 20), bg='black', fg='green',command=decryptageProjetRButton)
    label_decryptageProjetR.pack(side=TOP)
    entryDecryptageProjetR.pack(side=TOP)
    label_cleProjetR.pack(side=TOP)
    entryCleProjetR.pack(side=TOP)
    button_decryptageProjetR.pack(side=TOP,pady=20)
    label_texteDecrypteProjetR.pack(side=TOP)






#Main Window
frame = Frame(window, bg='Black')

label_title = Label(frame, text="D3CR1PT0", font=('',80), bg='black', fg='green')
label_title.pack(pady=25)

launch_button = Button(frame, text='Lancer', font=('',65), bg='Black', fg='green',command=openMenu)
launch_button.pack()

label_subtitle = Label(frame, text="Un logiciel de cryptage et de décryptage réalisé par F3l1X et CH4RLY", font=('',25), bg='black', fg='green')
label_subtitle.pack(pady=35)

frame.pack(expand=YES)


window.mainloop()